#！/usr/bin/python3.5

products_list = [
    ('telephone',2000),
    ('computer',12000),
    ('bicycle',20000),
    ('television',4500),
    ('kindle',1450),
]
shopping_list = []
salary = input("please input how much money you obtain: ")
if salary.isdigit():
    salary = int(salary)
    while True:
        for index,item in enumerate(products_list):
            print(index,item)
        user_choice = input("Please input the series number of the item you want to buy:")
        if user_choice.isdigit():
            user_choice = int(user_choice)
            if user_choice < len(products_list) and user_choice >= 0:
                p_item = products_list[user_choice]
                if p_item[1] <= salary:
                    shopping_list.append(p_item)
                    salary = salary - p_item[1]
                    print("\033[42;1m%s\033[0m is added to your cart and you have \033[31;1m%s\033[0m left." %(p_item[0],salary))
                else:
                    print("You do not have enough money left to buy anything!")
            else:
                print("You haven't input a valid series number of item!")
        elif user_choice == "q" or user_choice == "exit":
            print('------your shopping list------')
            for p in shopping_list:
                print(p)
            print("The money you have now:",salary)
            exit()
        else:
            print("invalid option,please retry.")
